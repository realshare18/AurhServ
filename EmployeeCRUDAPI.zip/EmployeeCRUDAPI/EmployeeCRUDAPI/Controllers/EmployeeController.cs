﻿using EmployeeCRUDAPI.Model;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;


namespace EmployeeCRUDAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly EmployeeDbContext _employeeDbContext;
        
       
        public EmployeeController(EmployeeDbContext employeeDbContext)
        {
            _employeeDbContext = employeeDbContext;
               
        }
        [HttpGet]
        public ActionResult GetAllEmployee()
        {
            return Ok(_employeeDbContext.EmployeeTbls.ToList());
        }
        [HttpPost]
        public ActionResult AddEmployee(Employee employee)
        {
            _employeeDbContext.EmployeeTbls.Add(employee);
            _employeeDbContext.SaveChanges();
            return Ok(employee);
        }


        [HttpPut]
        public ActionResult UpdateEmployee(Employee employee)
        {
            _employeeDbContext.Update(employee);
            _employeeDbContext.SaveChanges();
            return Ok(employee);
        }


        [HttpDelete("{id}")]
        public ActionResult DeleteEmployee(int id)
        {
            var entity = _employeeDbContext.EmployeeTbls.Where(s => s.EmployeeID == id).FirstOrDefault();
            if (entity == null)
            {
                throw new ArgumentNullException("Entity Missing");
            }
            _employeeDbContext.EmployeeTbls.Remove(entity);
            _employeeDbContext.SaveChanges();
            return Ok(entity);
        }

        [HttpPost]
        [Route("Upload")]
        public ActionResult Upload(IFormFile file)
        {
            try
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Wwwroot/Uploads", file.FileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }

                return Ok(new
                {
                    fileName = Path.Combine("Uploads", file.FileName)
                });
            }
            catch
            {
                return BadRequest();
            }
        }


    } 
}
