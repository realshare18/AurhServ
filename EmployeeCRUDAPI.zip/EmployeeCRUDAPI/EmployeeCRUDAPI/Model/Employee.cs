﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeCRUDAPI.Model
{
    public class Employee
    {
        [Key]
        public int EmployeeID { get; set; }
        
        [Column(TypeName = "nvarchar(50)")]
        public string Name { get; set; }
        public int Age { get; set; }

        public string Gender { get; set; }
        public string Department { get; set; }
        public decimal Salary { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string Address { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string Contact { get; set; }
    }
}
