﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_TokenAuthentication.DTOs
{
    public class RegisterDto
    {
        [Required]
        [StringLength(50,MinimumLength =3,ErrorMessage ="Full Name must be atleaast 3 Character")]
        public string FullName { get; set; }
        [Required]
        [StringLength(64,MinimumLength =3,ErrorMessage ="Email must be atleast 5 Character")]
        public string Email { get; set; }
        [Required]
        [StringLength(64,MinimumLength =8,ErrorMessage ="Password should be atleast 8 ad 20")]
        public string PassWord { get; set; }
    }
}
