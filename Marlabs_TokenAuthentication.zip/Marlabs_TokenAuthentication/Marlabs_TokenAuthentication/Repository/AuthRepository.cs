﻿//using Marlabs_TokenAuthentication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_TokenAuthentication.Repository
{
    public class AuthRepository : IAuthRepository
    {
    //    private readonly MarlabsTokenAuthenticatnContext _Context;
    //    public AuthRepository(MarlabsTokenAuthenticatnContext context)
    //    {
    //        this._Context = context;
    //    }
    //    public TblUser Login(string email)
    //    {
    //        var user = _Context.TblUsers.FirstOrDefault(x => x.Email == email);
    //        if (user == null)
    //            return null;

    //        return user;  //auth Successful
    //    }

    //    public TblUser Register(TblUser user)
    //    {
    //        _Context.TblUsers.Add(user);
    //        _Context.SaveChanges();
    //        return user;
    //    }
    //}
}
