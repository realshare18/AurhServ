﻿using AutoMapper;
using Marlabs_TokenAuthentication.DTOs;
using Marlabs_TokenAuthentication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_TokenAuthentication.Helpers
{
    public class AutoMapperProfile:Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<LoginDto, TblUser>();//CreateMap---Implict Mapping.

            CreateMap<RegisterDto, TblUser>();
        }
    }
}
